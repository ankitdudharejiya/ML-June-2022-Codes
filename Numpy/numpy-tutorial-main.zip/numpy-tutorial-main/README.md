# numpy-tutorial
This is a complete NumPy tutorial for beginners and you don't need to have any prior knowledge to get started. 
